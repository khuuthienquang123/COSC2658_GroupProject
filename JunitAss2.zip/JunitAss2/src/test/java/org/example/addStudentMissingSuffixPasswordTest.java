package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.ByteArrayInputStream;

import static org.junit.Assert.*;

public class addStudentMissingSuffixPasswordTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testAddStudent_MissingSuffixPassword() {
        String input = "7654333\nNewStudent\np1234567x\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        String result = event.AddStudent();
        assertTrue("Adding student with missing suffix in password should fail", result.contains("Last letter of the password should be #"));
    }
}