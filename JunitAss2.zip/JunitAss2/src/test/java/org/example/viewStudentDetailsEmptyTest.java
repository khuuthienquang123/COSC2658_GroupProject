package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class viewStudentDetailsEmptyTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
        Event.Student = new ArrayList<>();  // Clear the student list for this test
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testViewStudentDetails_WithoutStudents() {
        boolean result = event.viewStudentDetails();
        assertFalse("View student details should return false when there are no students", result);
        assertEquals("Student list should be empty", 0, Event.Student.size());
    }
}