package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.ByteArrayInputStream;

import static org.junit.Assert.*;

public class addStudentShortPasswordTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testAddStudent_ShortPassword() {
        String input = "7654333\nNewStudent\np1234#\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        String result = event.AddStudent();
        assertTrue("Adding student with short password should fail", result.contains("Password length should be 9"));
    }
}
