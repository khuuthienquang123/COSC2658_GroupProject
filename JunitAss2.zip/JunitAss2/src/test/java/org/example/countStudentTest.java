package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.*;

public class countStudentTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testCountStudent() {
        int count = event.countStudent();
        assertEquals("Student count should be 9", 9, count);
    }
}