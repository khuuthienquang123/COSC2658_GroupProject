package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.*;

public class viewStudentDetailsTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testViewStudentDetails_WithStudents() {
        boolean result = event.viewStudentDetails();
        assertTrue("View student details should return true when there are students", result);
        assertEquals("Student list size should match", 9, Event.Student.size());
    }
}
