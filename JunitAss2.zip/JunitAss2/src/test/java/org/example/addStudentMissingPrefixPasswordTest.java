package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.ByteArrayInputStream;

import static org.junit.Assert.*;

public class addStudentMissingPrefixPasswordTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testAddStudent_MissingPrefixPassword() {
        String input = "7654333\nNewStudent\nx1234567#\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        String result = event.AddStudent();
        assertTrue("Adding student with missing prefix in password should fail", result.contains("First letter of the Password should be p"));
    }
}