package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.*;

public class searchStudentInvalidIDTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testSearchStudent_InvalidID() {
        boolean result = event.searchStudentDetails(9999999);
        assertFalse("Searching for an invalid student ID should return false", result);
    }
}