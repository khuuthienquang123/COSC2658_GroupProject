package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.*;

public class searchStudentValidIDTest {
    private static Event event;

    @Before
    public void setUp() {
        event = new Event();
    }

    @After
    public void tearDown() {
        event = null;
    }

    @Test
    public void testSearchStudent_ValidID() {
        boolean result = event.searchStudentDetails(7654324);
        assertTrue("Searching for a valid student ID should return true", result);
    }
}
