package org.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class adminTestingValidLogin {
    private static Event event;
    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalSystemOut = System.out;
    private final InputStream originalSystemIn = System.in;

    @Before
    public void setUp() {
        event = new Event();
        System.setOut(new PrintStream(outputStream));
    }

    @After
    public void tearDown() {
        System.setOut(originalSystemOut);
        System.setIn(originalSystemIn);
        event = null;

    }

    @Test

    public void testAdminLogin_Valid() {
        String input = "Admin1\npass1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        boolean result = event.AdminLogin();
        assertTrue("Admin login with VALID credentials should succeed", result);
        assertNotNull("Event object should be initialized", event);
        assertEquals("Admin list should be initialized", 3, Event.Admin.size());
    }


}